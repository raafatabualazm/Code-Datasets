String reverse(String s) => new String.fromCharCodes(s.runes.toList().reversed);
