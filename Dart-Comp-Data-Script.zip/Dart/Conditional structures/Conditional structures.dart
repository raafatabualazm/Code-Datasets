
main() {
    var year = 1990;
    if (year >= 2001) {
        print('21st century');
    } else if (year >= 1901) {
        print('20th century');
    } else {
        print('Unknown');
    }
}