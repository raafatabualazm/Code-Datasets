makeAccumulator(s) => (n) => s += n;
