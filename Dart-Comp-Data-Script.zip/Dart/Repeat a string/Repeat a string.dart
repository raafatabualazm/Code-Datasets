
main() {
    print('ha'*5);
}