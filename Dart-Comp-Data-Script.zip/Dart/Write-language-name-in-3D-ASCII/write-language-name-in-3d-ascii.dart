void main(){
 print("""

 XXX       XX       XXX     XXXX
  X   X    X    X     X    X      X
   X   X    XXXX      XXX        X
    XXX      X    X      X   X      X
  """.replaceAll('X','_/'));
}
