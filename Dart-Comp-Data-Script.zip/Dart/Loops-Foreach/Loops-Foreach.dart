
main() {
    var n = ['Apple', 'Banana', 'Coconut'];
    n.forEach(print);
}