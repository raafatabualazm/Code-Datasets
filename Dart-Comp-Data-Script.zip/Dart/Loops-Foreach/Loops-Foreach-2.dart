
main() {
    var n = ['Apple', 'Banana', 'Coconut'];
    for(final i in n)
        print(i);
}