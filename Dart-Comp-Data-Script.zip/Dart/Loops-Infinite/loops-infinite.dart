main() {
  while(true) {
    print("SPAM");
  }
}
