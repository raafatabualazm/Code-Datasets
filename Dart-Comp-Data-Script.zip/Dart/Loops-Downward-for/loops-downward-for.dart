void main() {
  for (var i = 10; i >= 0; --i) {
    print(i);
  }
}
