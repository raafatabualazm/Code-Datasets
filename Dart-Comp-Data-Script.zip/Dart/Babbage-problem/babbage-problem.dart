main() {
	var x = 0;
	while((x*x)% 1000000 != 269696)
	{	x++;}
	
	print('$x');
}
