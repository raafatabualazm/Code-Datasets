import 'dart:io';

void main() {
    var a = int.parse(stdin.readLineSync()!);
    var b = int.parse(stdin.readLineSync()!);
    if (a < b) print('a is less than b');
    if (a == b) print('a is equal to b');
    if (a > b) print('a is greater than b');
}