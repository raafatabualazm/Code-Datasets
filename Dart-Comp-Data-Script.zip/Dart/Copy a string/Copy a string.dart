
main() {
    var s1 = 'hello';
    var s2 = s1;
    print(s2);
}