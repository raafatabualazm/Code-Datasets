
main() {
  print((int.parse('11')+1).toString());
}