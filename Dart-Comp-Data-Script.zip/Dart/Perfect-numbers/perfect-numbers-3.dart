main() =>
    new List.generate(1000,(i)=>i+1).where(isPerfect).forEach(print);
