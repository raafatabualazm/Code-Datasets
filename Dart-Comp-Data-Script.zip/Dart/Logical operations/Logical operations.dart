@pragma('vm:never-inline')
@pragma('vm:entry-point')
f(a,b) {
    print(a && b);
    print(a || b);
    print(! a);
}

@pragma('vm:never-inline')
@pragma('vm:entry-point')
main() {
    f(true, false);
}