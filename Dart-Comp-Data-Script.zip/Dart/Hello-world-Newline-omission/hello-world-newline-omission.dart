import 'dart:io';

void main() {
  stdout.write("Goodbye, World!");
}
