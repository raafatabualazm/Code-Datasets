#!/usr/bin/env dart

main() {
	var program = new Options().script;
	print("Program: ${program}");
}
