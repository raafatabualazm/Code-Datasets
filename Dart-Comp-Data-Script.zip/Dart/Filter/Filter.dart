@pragma('vm:never-inline')
@pragma('vm:entry-point')
main() {
    var l = List.generate(10,(i)=>i+1);
    print(l.where((i)=>i.isEven).toList());
}