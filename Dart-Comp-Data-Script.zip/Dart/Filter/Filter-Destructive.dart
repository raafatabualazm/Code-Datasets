@pragma('vm:never-inline')
@pragma('vm:entry-point')
main() {
    var l = List.generate(10,(i)=>i+1);
    l.retainWhere((i)=>i.isEven);
    print(l);
}