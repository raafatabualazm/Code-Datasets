import 'dart:io';

void main() {
  var line = stdin.readLineSync();
  stdout.write(line);
}
