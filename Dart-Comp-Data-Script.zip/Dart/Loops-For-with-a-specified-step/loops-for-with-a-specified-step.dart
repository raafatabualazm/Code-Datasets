main() {
  for (int i = 1; i <= 21; i += 2) print(i);
}
