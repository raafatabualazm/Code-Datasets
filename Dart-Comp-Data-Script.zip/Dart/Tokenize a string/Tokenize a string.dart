
main() {
    final s = 'Hello,How,Are,You,Today';
    print(s.split(',').join('.'));
}