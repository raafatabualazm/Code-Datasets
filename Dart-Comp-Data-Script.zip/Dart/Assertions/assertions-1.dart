main() {
  var i = 42;
  assert( i == 42 );
}
