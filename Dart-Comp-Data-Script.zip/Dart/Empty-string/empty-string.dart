main() {
  var empty = '';

  if (empty.isEmpty) {
    print('it is empty');
  }

  if (empty.isNotEmpty) {
    print('it is not empty');
  }
}
