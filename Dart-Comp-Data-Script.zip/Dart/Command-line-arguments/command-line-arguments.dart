main(List<String> args) {
    for(var arg in args)
        print(arg);
}
