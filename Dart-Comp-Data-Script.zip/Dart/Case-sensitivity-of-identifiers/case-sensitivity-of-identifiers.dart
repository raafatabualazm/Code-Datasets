void main() {
  String dog = "Benjamin", doG = "Smokey", Dog = "Samba", DOG = "Bernie";

  print("The four dogs are named $dog, $doG, $Dog and $DOG");
}
