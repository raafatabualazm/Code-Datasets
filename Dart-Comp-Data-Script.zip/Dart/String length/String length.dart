import 'dart:convert';


byteLen(s) => utf8.encode(s).length;


main() {
    print(byteLen('møøse'));
}