arrLength(arr) {
  return arr.length;
}

main() {
  var fruits = ['apple', 'orange'];
  print(arrLength(fruits));
}
