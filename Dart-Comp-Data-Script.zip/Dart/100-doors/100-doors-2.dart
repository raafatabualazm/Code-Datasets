main() {
  for(int i=1,s=3;i<=100;i+=s,s+=2)
    print("door $i is open");
}
