void main() {
  int val = 0;
  do {
    val++;
    print(val);
  } while (val % 6 != 0);
}
