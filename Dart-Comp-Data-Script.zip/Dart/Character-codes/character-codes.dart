void main() {
  const string = 'D';
  print(string.runes.first);
  var out = String.fromCharCode(67);
  print(out);
}
