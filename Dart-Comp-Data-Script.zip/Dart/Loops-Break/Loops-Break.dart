
var seed_ = DateTime.now().microsecondsSinceEpoch;

next() => seed_ = (17 * seed_ + 1) % 65521;


void main() {
    while(true) {
        var a = next()%20;
        print(a);
        if(a == 10) break;
        print(next()%20);
    }
}