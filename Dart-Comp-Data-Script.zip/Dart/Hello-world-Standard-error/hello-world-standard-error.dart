import 'dart:io';

void main() {
  stderr.writeln('Goodbye, World!');
}
