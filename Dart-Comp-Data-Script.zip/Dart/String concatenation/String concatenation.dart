
main() {
    var s1 = 'hello';
    var s2 = ' world';
    print(s1 + s2);
}