main() {
    var bye = 'Hello world!';
    print("$bye");
}
