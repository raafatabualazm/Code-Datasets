void main() {
  var val = 1024;
  while (val > 0) {
    print(val);
    val >>= 1;
  }
}
