import 'dart:math';

void main() {
  var resul = pow(0, 0);
  print("0 ^ 0 = $resul");
}
