#library("scriptedmain");


meaningOfLife() {
	return 42;
}


main() {
	print("Main: The meaning of life is ${meaningOfLife()}");
}