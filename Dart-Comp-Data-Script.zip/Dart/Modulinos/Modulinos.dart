
import("scriptedmain.dart", prefix: "scriptedmain");


main() {
	print("Test: The meaning of life is ${scriptedmain.meaningOfLife()}");
}