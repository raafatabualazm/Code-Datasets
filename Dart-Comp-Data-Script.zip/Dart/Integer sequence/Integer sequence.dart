
void main() {
   var a = 1;
   while(true) {
      print(a);
      a++;
   }
}