import 'dart:html';

main() => document.body.innerHtml = '<p>Goodbye, World!</p>';
