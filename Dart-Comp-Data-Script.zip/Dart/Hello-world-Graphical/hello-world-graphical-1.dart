import 'package:flutter/material.dart';

main() => runApp( MaterialApp( home: Text( "Goodbye, World!" ) ) );
