import 'dart:html';

main() => window.alert("Goodbye, World!");
