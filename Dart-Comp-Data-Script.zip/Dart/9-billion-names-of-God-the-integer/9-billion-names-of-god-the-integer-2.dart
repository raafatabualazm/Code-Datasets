 import 'package:dart-1.dart' as names_of_god;

main(List<String> arguments) {
  names_of_god.printRows(min: 1, max: 11);
  names_of_god.printSums([23, 123, 1234, 12345]);
}
