main()=>(s){print('$s(r\x22$s\x22);');}(r"main()=>(s){print('$s(r\x22$s\x22);');}");
