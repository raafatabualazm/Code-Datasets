import os
import re
import json
import argparse
import subprocess
import shutil
from pathlib import Path

# Improved function / method signature matcher
FUNCTION_RE = re.compile(
    r"""^                              # start of line
        \s*                            # indentation
        (?:@\w[^\n]*\n\s*)*           # optional metadata annotations
        (?:(?:static|external|factory|
            const|covariant|late|
            abstract)\s+)*             # modifiers (any order)
        (?:async\*?|sync\*?\s+)?       # async / async* / sync* (optional)
        (?:\w+(?:<[^>]+>)?\s+)?        # return type (optional)
        (?P<name>\w+)\s*               # function or method name
        \([^;]*?\)                     # parameter list (no ';' allowed)
        \s*(?:\{|=>)                   # body opener
    """,
    re.MULTILINE | re.VERBOSE,
)

# Class definition pattern
CLASS_RE = re.compile(
    r"""class\s+                       # class keyword
        (?P<name>\w+)                  # class name
        (?:<[^>]+>)?                   # optional generics
        (?:\s+extends\s+[^{]+)?        # optional extends
        (?:\s+with\s+[^{]+)?           # optional with (mixins)
        (?:\s+implements\s+[^{]+)?     # optional implements
        \s*{                           # opening brace
    """, 
    re.VERBOSE
)

def extract_functions_with_source(dart_file_path):
    """
    Extract functions from a Dart file, including class methods, along with source code.
    Returns a list of dictionaries with function information.
    """
    functions = []
    
    try:
        with open(dart_file_path, 'r', encoding='utf-8') as file:
            content = file.read()
            
            # Extract classes
            class_matches = list(CLASS_RE.finditer(content))
            classes = {}
            
            for match in class_matches:
                class_name = match.group('name')
                class_start = match.start()
                
                # Find class end (matching closing brace)
                brace_level = 0
                class_end = class_start
                for i, char in enumerate(content[class_start:], class_start):
                    if char == '{':
                        brace_level += 1
                    elif char == '}':
                        brace_level -= 1
                        if brace_level == 0:
                            class_end = i
                            break
                
                classes[class_name] = (class_start, class_end)
            
            # Find all functions
            function_matches = list(FUNCTION_RE.finditer(content))
            
            for match in function_matches:
                function_name = match.group('name')
                
                # Skip private functions
                if function_name.startswith('_'):
                    continue
                
                # Find function boundaries
                start_pos = match.start()
                end_pos = match.end() - 1  # just before the { or =>
                
                # Find the end of the function
                if content[end_pos] == '{':
                    # Function with a body
                    brace_level = 1
                    pos = end_pos + 1
                    while pos < len(content) and brace_level > 0:
                        if content[pos] == '{':
                            brace_level += 1
                        elif content[pos] == '}':
                            brace_level -= 1
                        pos += 1
                    function_end = pos
                else:
                    # Arrow function
                    pos = end_pos + 2  # skip the =>
                    while pos < len(content) and content[pos] != ';' and content[pos] != '\n':
                        pos += 1
                    if pos < len(content) and content[pos] == ';':
                        pos += 1  # include the semicolon
                    function_end = pos
                
                # Get the function source code
                source_code = content[start_pos:function_end].strip()
                
                # Check if this function is inside a class
                pos = match.start()
                in_class = False
                class_name = None
                
                for name, (start, end) in classes.items():
                    if start < pos < end:
                        in_class = True
                        class_name = name
                        break
                
                if in_class:
                    full_name = f"{class_name}.{function_name}"
                else:
                    full_name = function_name
                
                functions.append({
                    'name': full_name,
                    'source': source_code,
                    'assembly': None  # Will be filled in later if successful
                })
                    
    except Exception as e:
        print(f"Error processing {dart_file_path}: {e}")
    
    return functions

def compile_dart_to_aot(dart_file_path, output_path):
    """Compile a Dart file to an AOT snapshot."""
    try:
        # Create a temporary directory for the output
        temp_dir = os.path.dirname(output_path)
        os.makedirs(temp_dir, exist_ok=True)
        
        # Run the dart compile aot-snapshot command
        result = subprocess.run(
            [
                'dart', 'compile', 'aot-snapshot',
                '-o', output_path,
                dart_file_path
            ],
            capture_output=True,
            text=True,
            check=False  # Don't raise exception on non-zero exit
        )
        
        # Check if compilation was successful
        if result.returncode == 0:
            print(f"Successfully compiled {dart_file_path} to AOT snapshot")
            return True
        else:
            print(f"Failed to compile {dart_file_path}: {result.stderr}")
            return False
    except Exception as e:
        print(f"Error compiling {dart_file_path}: {e}")
        return False

def get_symbol_table(aot_file):
    """Get the symbol table from the AOT snapshot using GDB."""
    try:
        # Run GDB to get the symbol table
        result = subprocess.run(
            [
                'gdb', '--quiet', '--batch',
                '-ex', f'file "{aot_file}"',
                '-ex', "info functions"
            ],
            capture_output=True,
            text=True,
            check=False
        )
        
        if result.returncode == 0:
            return result.stdout
        else:
            print(f"Failed to get symbol table: {result.stderr}")
            return ""
    except Exception as e:
        print(f"Error getting symbol table: {e}")
        return ""

def get_function_assembly(aot_file, function_name):
    """Get assembly for a function using GDB."""
    try:
        # Run GDB to disassemble the function
        result = subprocess.run(
            [
                'gdb', '--quiet', '--batch',
                '-ex', "set disassembly-flavor intel",
                '-ex', f'file "{aot_file}"',
                '-ex', f"disassemble {function_name}"
            ],
            capture_output=True,
            text=True,
            check=False
        )
        
        if result.returncode == 0 and "No symbol" not in result.stdout:
            return result.stdout
        else:
            return None
    except Exception as e:
        print(f"Error disassembling {function_name}: {e}")
        return None

def extract_assembly_with_gdb(aot_file, functions, output_dir, base_filename):
    """
    Use GDB to extract assembly for each function from the AOT snapshot.
    Updates the functions list with assembly code if successful.
    Returns the file data for the consolidated JSON.
    """
    try:
        # Create an output directory for assembly files
        assembly_dir = os.path.join(output_dir, "assembly")
        os.makedirs(assembly_dir, exist_ok=True)
        
        # Get the symbol table
        symbol_table = get_symbol_table(aot_file)
        
        # List of name patterns to try for each function
        function_names = [f['name'] for f in functions]
        
        # Parse symbol table to find actual symbol names
        symbol_map = {}
        
        for func_name in function_names:
            if '.' in func_name:
                # Handle class methods
                class_name, method_name = func_name.split('.')
                patterns = [
                    # Standard patterns
                    func_name,
                    f"{class_name}_{method_name}",
                    f"_{class_name}_{method_name}",
                    # Dart specific mangling patterns
                    f"__{class_name}_{method_name}",
                    f"Dart_{class_name}_{method_name}",
                    # Static methods may have different patterns
                    f"static_{class_name}_{method_name}",
                    # Factory constructors
                    f"factory_{class_name}_{method_name}",
                    # Getters and setters
                    f"get_{class_name}_{method_name}",
                    f"set_{class_name}_{method_name}"
                ]
            else:
                # Handle regular functions
                patterns = [
                    func_name,
                    f"_{func_name}",
                    f"__{func_name}",
                    f"Dart_{func_name}"
                ]
                
            # Find the first matching pattern in the symbols
            for pattern in patterns:
                # Use a regex that ensures we're matching the function name properly
                regex = r'\S+\s+[^(]*?' + re.escape(pattern) + r'(?:\(|$)'
                matches = re.findall(regex, symbol_table)
                if matches:
                    # Extract just the function name from the match
                    symbol = matches[0].split()[-1].split('(')[0]
                    symbol_map[func_name] = symbol
                    break
        
        # Extract assembly for each function
        for func_idx, func in enumerate(functions):
            func_name = func['name']
            safe_name = func_name.replace('.', '_')
            assembly_output_file = os.path.join(assembly_dir, f"{safe_name}_assembly.asm")
            
            # If we found a matching symbol, use it
            if func_name in symbol_map:
                actual_symbol = symbol_map[func_name]
                assembly = get_function_assembly(aot_file, actual_symbol)
            else:
                # Try various naming patterns
                assembly = None
                if '.' in func_name:
                    # Class methods
                    class_name, method_name = func_name.split('.')
                    patterns = [
                        func_name,
                        f"{class_name}_{method_name}",
                        f"_{class_name}_{method_name}",
                        f"__{class_name}_{method_name}",
                        f"Dart_{class_name}_{method_name}"
                    ]
                else:
                    # Regular functions
                    patterns = [
                        func_name,
                        f"_{func_name}",
                        f"__{func_name}",
                        f"Dart_{func_name}"
                    ]
                
                # Try each pattern
                for pattern in patterns:
                    assembly = get_function_assembly(aot_file, pattern)
                    if assembly:
                        break
            
            # Save assembly to file if successful
            if assembly:
                with open(assembly_output_file, 'w') as f:
                    f.write(assembly)
                functions[func_idx]['assembly'] = assembly
        
        # Second pass: Try to extract assembly for functions that failed using the actual txt file
        failed_functions = [i for i, func in enumerate(functions) if func['assembly'] is None]
        
        if failed_functions:
            print(f"Attempting second pass for {len(failed_functions)} functions that failed initial extraction...")
            
            # Use the actual output txt file that will be created later
            actual_output_file = os.path.join(output_dir, f"{base_filename}_functions.txt")
            
            # Create the txt file now so we can read from it
            with open(actual_output_file, 'w', encoding='utf-8') as f:
                for function in functions:
                    f.write(f"{function['name']}\n")
            
            # Read function names from the actual txt file
            try:
                with open(actual_output_file, 'r', encoding='utf-8') as f:
                    txt_function_names = [line.strip() for line in f.readlines() if line.strip()]
                
                print(f"Read {len(txt_function_names)} function names from {actual_output_file}")
                
                # Try alternative extraction methods for failed functions
                for func_idx in failed_functions:
                    func_name = functions[func_idx]['name']
                    
                    if func_name in txt_function_names:
                        print(f"Retrying assembly extraction for: {func_name}")
                        
                        # Try even more aggressive pattern matching
                        alternative_patterns = []
                        
                        if '.' in func_name:
                            class_name, method_name = func_name.split('.')
                            alternative_patterns.extend([
                                # More Dart-specific patterns
                                f"[_{class_name}]*{method_name}",
                                f"*{class_name}*{method_name}*",
                                f"*{method_name}*",
                                # Constructor patterns
                                f"{class_name}.*{method_name}",
                                f"*ctor*{method_name}",
                                # Getter/setter patterns  
                                f"*get*{method_name}*",
                                f"*set*{method_name}*",
                                # Remove special characters and try
                                method_name.replace('_', ''),
                                f"*{method_name.replace('_', '')}*"
                            ])
                        else:
                            alternative_patterns.extend([
                                f"*{func_name}*",
                                f"main*{func_name}*",
                                f"*{func_name.replace('_', '')}*",
                                func_name.replace('_', ''),
                                f"*{func_name}",
                                f"{func_name}*"
                            ])
                        
                        # Try wildcard searches in GDB
                        assembly = None
                        for pattern in alternative_patterns:
                            try:
                                # Use GDB's info functions with wildcards
                                result = subprocess.run(
                                    [
                                        'gdb', '--quiet', '--batch',
                                        '-ex', f'file "{aot_file}"',
                                        '-ex', f"info functions {pattern}"
                                    ],
                                    capture_output=True,
                                    text=True,
                                    check=False
                                )
                                
                                if result.returncode == 0 and result.stdout.strip():
                                    # Parse the output to find actual function names
                                    lines = result.stdout.split('\n')
                                    for line in lines:
                                        if 'File' not in line and line.strip() and not line.startswith('All functions'):
                                            # Extract function name from GDB output
                                            parts = line.strip().split()
                                            if len(parts) >= 2:
                                                potential_symbol = parts[-1].split('(')[0]
                                                # Try to disassemble this symbol
                                                test_assembly = get_function_assembly(aot_file, potential_symbol)
                                                if test_assembly:
                                                    assembly = test_assembly
                                                    print(f"Found assembly for {func_name} using pattern {pattern} -> {potential_symbol}")
                                                    break
                                
                                if assembly:
                                    break
                                    
                            except Exception as e:
                                continue
                        
                        # If we found assembly, save it
                        if assembly:
                            safe_name = func_name.replace('.', '_')
                            assembly_output_file = os.path.join(assembly_dir, f"{safe_name}_assembly.asm")
                            with open(assembly_output_file, 'w') as f:
                                f.write(assembly)
                            functions[func_idx]['assembly'] = assembly
                            print(f"Successfully extracted assembly for {func_name} on second pass")
                        else:
                            print(f"Failed to extract assembly for {func_name} even on second pass")
                            
            except Exception as e:
                print(f"Error during second pass extraction: {e}")
        
        # Create individual JSON file (keeping original functionality)
        json_output_file = os.path.join(output_dir, f"{base_filename}_functions.json")
        with open(json_output_file, 'w', encoding='utf-8') as f:
            # Include ALL functions, even if assembly extraction failed
            json_functions = []
            for func in functions:
                json_functions.append({
                    'name': func['name'],
                    'source': func['source'],
                    'assembly': func['assembly']  # This will be None if extraction failed
                })
            
            json.dump({
                'file': base_filename + '.dart',
                'functions': json_functions
            }, f, indent=2)
        
        print(f"Created JSON mapping of functions and assembly for {base_filename}")
        
        # Return file data for consolidated JSON (include all functions)
        if functions:
            return {
                'file': base_filename + '.dart',
                'functions': functions
            }
        else:
            return None
    
    except Exception as e:
        print(f"Error extracting assembly: {e}")
        return None

def process_directory(source_root, dest_root, current_dir, successful_dirs=None, all_file_data=None):
    """Process a directory recursively for Dart files."""
    if successful_dirs is None:
        successful_dirs = set()
    if all_file_data is None:
        all_file_data = []
        
    # Get the relative path from source_root
    rel_path = os.path.relpath(current_dir, source_root)
    target_dir = os.path.join(dest_root, rel_path)
    
    # Track if we had at least one successful compilation in this directory
    success_in_dir = False
    
    # Iterate through all items in the current directory
    for item in os.listdir(current_dir):
        item_path = os.path.join(current_dir, item)
        
        if os.path.isdir(item_path):
            # Recursively process subdirectories
            sub_success = process_directory(source_root, dest_root, item_path, successful_dirs, all_file_data)
            success_in_dir = success_in_dir or sub_success
        elif item.endswith('.dart'):
            base_filename = os.path.splitext(item)[0]
            snapshot_name = f"{base_filename}.aot"
            snapshot_path = os.path.join(target_dir, snapshot_name)
            
            # Try to compile the Dart file to AOT snapshot
            if compile_dart_to_aot(item_path, snapshot_path):
                # Compilation successful
                success_in_dir = True
                
                # Create the target directory now that we know compilation succeeded
                os.makedirs(target_dir, exist_ok=True)
                
                # Mark this directory and all parent directories as successful
                successful_dirs.add(target_dir)
                current_path = os.path.dirname(target_dir)
                while current_path and current_path != dest_root and current_path.startswith(dest_root):
                    successful_dirs.add(current_path)
                    current_path = os.path.dirname(current_path)
                
                # Extract functions with source code
                functions = extract_functions_with_source(item_path)
                
                if functions:
                    # Extract assembly and update functions with assembly code
                    file_data = extract_assembly_with_gdb(snapshot_path, functions, target_dir, base_filename)
                    
                    # Add to consolidated data if successful
                    if file_data:
                        all_file_data.append(file_data)
                    
                    # Create output file with just the function names (for compatibility)
                    output_file = os.path.join(target_dir, f"{base_filename}_functions.txt")
                    with open(output_file, 'w', encoding='utf-8') as f:
                        for function in functions:
                            f.write(f"{function['name']}\n")
                else:
                    print(f"No functions found in {item_path}")
                
                # Copy the original Dart file
                source_file = os.path.join(current_dir, item)
                dest_file = os.path.join(target_dir, item)
                shutil.copy2(source_file, dest_file)
                print(f"Copied {source_file} to {dest_file}")
                
            else:
                # Compilation failed
                print(f"Skipping {item_path} due to compilation failure")
    
    # Clean up empty directories that didn't have any successful compilations
    if not success_in_dir and os.path.exists(target_dir) and target_dir not in successful_dirs:
        try:
            # Check if the directory is empty
            if os.path.exists(target_dir) and not os.listdir(target_dir):
                os.rmdir(target_dir)
                print(f"Removed empty directory {target_dir}")
        except Exception as e:
            print(f"Error removing directory {target_dir}: {e}")
    
    return success_in_dir

def main():
    parser = argparse.ArgumentParser(description='Process Dart files: extract functions, create AOT snapshots, and extract assembly code.')
    parser.add_argument('source', help='Source directory containing Dart files')
    parser.add_argument('destination', help='Destination directory for output files')
    parser.add_argument('--file', action='store_true', help='Process a single file instead of a directory')
    
    args = parser.parse_args()
    
    source_path = os.path.abspath(args.source)
    dest_dir = os.path.abspath(args.destination)
    
    # Ensure source exists
    if not os.path.exists(source_path):
        print(f"Error: Source '{source_path}' does not exist.")
        return
    
    # Check if GDB is installed
    try:
        subprocess.run(['gdb', '--version'], capture_output=True, check=True)
    except (subprocess.SubprocessError, FileNotFoundError):
        print("Error: GDB is not installed or not in the PATH. Please install GDB to extract assembly code.")
        return
    
    # Create destination root directory
    os.makedirs(dest_dir, exist_ok=True)
    
    # List to collect all file data for consolidated JSON
    all_file_data = []
    
    if args.file:
        # Process a single file
        if not os.path.isfile(source_path):
            print(f"Error: '{source_path}' is not a file.")
            return
        
        if not source_path.endswith('.dart'):
            print(f"Error: '{source_path}' is not a Dart file.")
            return
        
        # For single file processing, create a simple directory structure
        base_filename = os.path.splitext(os.path.basename(source_path))[0]
        snapshot_path = os.path.join(dest_dir, f"{base_filename}.aot")
        
        if compile_dart_to_aot(source_path, snapshot_path):
            # Extract functions with source code
            functions = extract_functions_with_source(source_path)
            
            if functions:
                # Extract assembly and create JSON mapping
                file_data = extract_assembly_with_gdb(snapshot_path, functions, dest_dir, base_filename)
                
                # Add to consolidated data if successful
                if file_data:
                    all_file_data.append(file_data)
                
                # Create output file with just the function names (for compatibility)
                output_file = os.path.join(dest_dir, f"{base_filename}_functions.txt")
                with open(output_file, 'w', encoding='utf-8') as f:
                    for function in functions:
                        f.write(f"{function['name']}\n")
            else:
                print(f"No functions found in {source_path}")
            
            # Copy the original Dart file
            dest_file = os.path.join(dest_dir, os.path.basename(source_path))
            shutil.copy2(source_path, dest_file)
        else:
            print(f"Failed to compile {source_path}")
    else:
        # Process a directory
        if not os.path.isdir(source_path):
            print(f"Error: '{source_path}' is not a directory.")
            return
        
        print(f"Processing Dart files from '{source_path}' to '{dest_dir}'...")
        process_directory(source_path, dest_dir, source_path, all_file_data=all_file_data)
    
    # Create consolidated JSON file with all data
    if all_file_data:
        consolidated_json_path = os.path.join(dest_dir, "consolidated_functions.json")
        with open(consolidated_json_path, 'w', encoding='utf-8') as f:
            json.dump({
                "data": all_file_data
            }, f, indent=2)
        print(f"Created consolidated JSON file: {consolidated_json_path}")
        print(f"Total files processed: {len(all_file_data)}")
    else:
        print("No successful function extractions found.")
    
    # Clean up any remaining empty directories in the destination
    for root, dirs, files in os.walk(dest_dir, topdown=False):
        for d in dirs:
            dir_path = os.path.join(root, d)
            if not os.listdir(dir_path):
                os.rmdir(dir_path)
                print(f"Removed empty directory {dir_path}")
    
    print("Done!")

if __name__ == "__main__":
    main()