#!/usr/bin/env python3

import os
import sys
import json
import subprocess
import tempfile
import shutil
import re
from pathlib import Path
from typing import List, Dict, Optional, Tuple

class SwiftAnalyzer:
    def __init__(self, source_dir: str, output_dir: str):
        self.source_dir = Path(source_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.json_files = []
        self.all_analysis_data = []
        
    def find_swift_files(self) -> List[Path]:
        """Recursively find all Swift files in the source directory."""
        swift_files = []
        for root, dirs, files in os.walk(self.source_dir):
            for file in files:
                if file.endswith('.swift'):
                    swift_files.append(Path(root) / file)
        return swift_files
    
    def extract_functions_from_source(self, source_content: str) -> Tuple[List[Dict[str, str]], Optional[str]]:
        """Extract function definitions from Swift source code and top-level code."""
        functions = []
        lines = source_content.split('\n')
        
        # Regex pattern to match Swift function declarations
        func_pattern = re.compile(r'^\s*((?:public|private|internal|fileprivate|open)?\s*)?(?:static\s+|class\s+)?func\s+(\w+)')
        
        # Track which lines are part of functions
        function_lines = set()
        
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            match = func_pattern.match(lines[i])
            
            if match:
                func_name = match.group(2)
                func_start = i
                
                # Find the function body by tracking braces
                brace_count = 0
                func_lines = []
                j = i
                
                # Handle function signature that might span multiple lines
                while j < len(lines):
                    current_line = lines[j]
                    func_lines.append(current_line)
                    function_lines.add(j)  # Mark this line as part of a function
                    
                    # Count braces to find function end
                    for char in current_line:
                        if char == '{':
                            brace_count += 1
                        elif char == '}':
                            brace_count -= 1
                            
                    # If we've closed all braces and we had at least one opening brace
                    if brace_count == 0 and '{' in '\n'.join(func_lines):
                        break
                        
                    j += 1
                
                func_source = '\n'.join(func_lines)
                functions.append({
                    'name': func_name,
                    'source': func_source
                })
                
                i = j + 1
            else:
                i += 1
        
        # Extract top-level code (code not inside functions)
        top_level_lines = []
        for i, line in enumerate(lines):
            if i not in function_lines:
                # Skip empty lines, comments, and imports for top-level code
                stripped = line.strip()
                if stripped and not stripped.startswith('//') and not stripped.startswith('import'):
                    top_level_lines.append(line)
        
        top_level_code = '\n'.join(top_level_lines) if top_level_lines else None
        
        return functions, top_level_code
    
    def compile_swift_file(self, swift_file: Path, output_binary: Path) -> bool:
        """Compile Swift file with no optimization and debug symbols."""
        try:
            # Swift compiler flags for no optimization and debug info
            cmd = [
                'swiftc',
                '-Onone',  # No optimization
                '-g',   # Debug symbols
                '-o', str(output_binary),
                str(swift_file)
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            return result.returncode == 0
            
        except (subprocess.TimeoutExpired, subprocess.SubprocessError, FileNotFoundError):
            return False
    
    def get_binary_symbols(self, binary_path: Path) -> Dict[str, str]:
        """Get all symbols from the binary and try to demangle them."""
        symbols = {}
        try:
            # Use nm to get all symbols
            cmd = ['nm', '-C', str(binary_path)]  # -C for demangling
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if ' T ' in line:  # Text (code) symbols
                        parts = line.strip().split(' ')
                        if len(parts) >= 3:
                            symbol_name = ' '.join(parts[2:])
                            # Store both mangled and demangled versions
                            symbols[symbol_name] = symbol_name
            
            # Also try objdump for more symbol info
            cmd = ['objdump', '-t', str(binary_path)]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if '.text' in line and 'F' in line:  # Function symbols in text section
                        parts = line.strip().split()
                        if len(parts) >= 6:
                            symbol_name = parts[-1]
                            symbols[symbol_name] = symbol_name
                            
        except (subprocess.TimeoutExpired, subprocess.SubprocessError, FileNotFoundError):
            pass
            
        return symbols
    
    def find_mangled_function_name(self, symbols: Dict[str, str], function_name: str) -> Optional[str]:
        """Try to find the mangled name for a Swift function."""
        # Look for exact matches first
        for symbol in symbols:
            if symbol == function_name:
                return symbol
        
        # Look for symbols containing the function name
        candidates = []
        for symbol in symbols:
            if function_name in symbol:
                candidates.append(symbol)
        
        # Prefer Swift-mangled symbols (starting with _$s or containing the function name)
        for candidate in candidates:
            if candidate.startswith('_$s') or candidate.startswith('$s'):
                return candidate
        
        # Return the first candidate if any
        return candidates[0] if candidates else None
    
    def get_function_disassembly(self, binary_path: Path, function_name: str, symbols: Dict[str, str]) -> Optional[str]:
        """Use GDB to get disassembly of a specific function in Intel syntax."""
        try:
            # Try to find the mangled function name
            mangled_name = self.find_mangled_function_name(symbols, function_name)
            target_name = mangled_name if mangled_name else function_name
            
            # Create GDB commands - try multiple approaches
            gdb_commands = [
                'set disassembly-flavor intel',
                'set pagination off',
                f'info functions {function_name}',  # List functions matching the name
                f'disassemble {target_name}',  # Try to disassemble
                'quit'
            ]
            
            # Write commands to temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.gdb', delete=False) as f:
                f.write('\n'.join(gdb_commands))
                gdb_script = f.name
            
            try:
                # Run GDB with the script
                cmd = ['gdb', '-batch', '-x', gdb_script, str(binary_path)]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0:
                    output = result.stdout
                    
                    # If direct disassembly failed, try to find the function in 'info functions' output
                    if 'No function contains program counter' in output or 'No symbol table' in output:
                        # Extract function names from 'info functions' output
                        lines = output.split('\n')
                        found_functions = []
                        
                        for line in lines:
                            if function_name in line and ('0x' in line or 'File' not in line):
                                # Try to extract the actual symbol name
                                parts = line.strip().split()
                                for part in parts:
                                    if function_name in part or part.startswith('_$s'):
                                        found_functions.append(part)
                        
                        # Try disassembling the found functions
                        if found_functions:
                            for found_func in found_functions:
                                try:
                                    disasm_cmd = [
                                        'gdb', '-batch', '-ex', 'set disassembly-flavor intel',
                                        '-ex', f'disassemble {found_func}',
                                        str(binary_path)
                                    ]
                                    disasm_result = subprocess.run(disasm_cmd, capture_output=True, text=True, timeout=15)
                                    if disasm_result.returncode == 0 and 'Dump of assembler code' in disasm_result.stdout:
                                        return self.extract_disassembly_from_output(disasm_result.stdout)
                                except:
                                    continue
                    
                    # Try to extract disassembly from the original output
                    return self.extract_disassembly_from_output(output)
                    
            finally:
                # Clean up temporary GDB script
                try:
                    os.unlink(gdb_script)
                except:
                    pass
                    
        except (subprocess.TimeoutExpired, subprocess.SubprocessError, FileNotFoundError):
            pass
            
        return None
    
    def extract_disassembly_from_output(self, gdb_output: str) -> Optional[str]:
        """Extract disassembly section from GDB output."""
        output_lines = gdb_output.split('\n')
        disassembly_lines = []
        in_disassembly = False
        
        for line in output_lines:
            if 'Dump of assembler code for function' in line:
                in_disassembly = True
                disassembly_lines.append(line)
            elif 'End of assembler dump' in line:
                disassembly_lines.append(line)
                break
            elif in_disassembly:
                disassembly_lines.append(line)
        
        return '\n'.join(disassembly_lines) if disassembly_lines else None
    
    def get_main_disassembly(self, binary_path: Path) -> Optional[str]:
        """Get disassembly of main function and top-level code."""
        try:
            # Try to disassemble main and other entry points
            main_functions = ['main', '_main', '$main', 'swift_main']
            
            for main_func in main_functions:
                try:
                    cmd = [
                        'gdb', '-batch', 
                        '-ex', 'set disassembly-flavor intel',
                        '-ex', 'set pagination off',
                        '-ex', f'disassemble {main_func}',
                        str(binary_path)
                    ]
                    result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
                    
                    if result.returncode == 0 and 'Dump of assembler code' in result.stdout:
                        return self.extract_disassembly_from_output(result.stdout)
                except:
                    continue
                    
            # If no main found, try to disassemble from entry point
            try:
                cmd = [
                    'gdb', '-batch',
                    '-ex', 'set disassembly-flavor intel', 
                    '-ex', 'set pagination off',
                    '-ex', 'info files',  # Get entry point
                    '-ex', 'disassemble _start',
                    str(binary_path)
                ]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
                
                if result.returncode == 0:
                    return self.extract_disassembly_from_output(result.stdout)
            except:
                pass
                
        except (subprocess.TimeoutExpired, subprocess.SubprocessError, FileNotFoundError):
            pass
            
        return None
    
    def process_swift_file(self, swift_file: Path) -> Optional[str]:
        """Process a single Swift file and generate JSON output."""
        print(f"Processing: {swift_file}")
        
        # Create output directory for this file
        relative_path = swift_file.relative_to(self.source_dir)
        file_output_dir = self.output_dir / relative_path.parent
        file_output_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            # Read source content
            with open(swift_file, 'r', encoding='utf-8') as f:
                source_content = f.read()
            
            # Compile the Swift file first
            binary_name = swift_file.stem + '_binary'
            binary_path = file_output_dir / binary_name
            
            if not self.compile_swift_file(swift_file, binary_path):
                print(f"Failed to compile {swift_file}, removing output directory")
                if file_output_dir.exists():
                    shutil.rmtree(file_output_dir)
                return None
            
            # Extract functions from source
            functions, top_level_code = self.extract_functions_from_source(source_content)
            
            # Get binary symbols for name mangling resolution
            symbols = self.get_binary_symbols(binary_path)
            
            # Process each function
            processed_functions = []
            
            # Add top-level code if it exists
            if top_level_code:
                main_disassembly = self.get_main_disassembly(binary_path)
                processed_functions.append({
                    'Function': '<top-level>',
                    'Source': top_level_code,
                    'Assembly': main_disassembly if main_disassembly else "Could not disassemble top-level code"
                })
            
            # Process regular functions
            for func_info in functions:
                func_name = func_info['name']
                func_source = func_info['source']
                
                # Get disassembly with name mangling support
                disassembly = self.get_function_disassembly(binary_path, func_name, symbols)
                
                processed_functions.append({
                    'Function': func_name,
                    'Source': func_source,
                    'Assembly': disassembly if disassembly else f"Could not disassemble function: {func_name}"
                })
            
            if not processed_functions:
                print(f"No functions or top-level code found in {swift_file}")
                return None
            
            # Create JSON output for individual file
            json_data = {
                'File': str(swift_file),
                'Functions': processed_functions
            }
            
            # Write individual JSON file
            json_filename = swift_file.stem + '_analysis.json'
            json_path = file_output_dir / json_filename
            
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=2, ensure_ascii=False)
            
            print(f"Generated: {json_path}")
            
            # Prepare data for final JSON (with lowercase field names)
            final_json_functions = []
            for func in processed_functions:
                final_json_functions.append({
                    'name': func['Function'],
                    'source': func['Source'],
                    'assembly': func['Assembly']
                })
            
            final_json_entry = {
                'file': swift_file.name,  # Just the filename, not full path
                'functions': final_json_functions
            }
            
            self.all_analysis_data.append(final_json_entry)
            
            # Clean up binary
            try:
                if binary_path.exists():
                    binary_path.unlink()
            except:
                pass
                
            return str(json_path)
            
        except Exception as e:
            print(f"Error processing {swift_file}: {e}")
            # Remove output directory on error
            if file_output_dir.exists():
                shutil.rmtree(file_output_dir)
            return None
    
    def create_final_json(self):
        """Create final JSON file with all analysis data embedded."""
        final_data = {
            'data': self.all_analysis_data
        }
        
        final_json_path = self.output_dir / 'final_analysis.json'
        with open(final_json_path, 'w', encoding='utf-8') as f:
            json.dump(final_data, f, indent=2, ensure_ascii=False)
        
        print(f"Final JSON created: {final_json_path}")
        print(f"Total files processed: {len(self.all_analysis_data)}")
        total_functions = sum(len(entry['functions']) for entry in self.all_analysis_data)
        print(f"Total functions analyzed: {total_functions}")
    
    def run(self):
        """Main execution method."""
        print(f"Analyzing Swift files in: {self.source_dir}")
        print(f"Output directory: {self.output_dir}")
        
        swift_files = self.find_swift_files()
        
        if not swift_files:
            print("No Swift files found!")
            return
        
        print(f"Found {len(swift_files)} Swift files")
        
        for swift_file in swift_files:
            json_path = self.process_swift_file(swift_file)
            if json_path:
                self.json_files.append(json_path)
        
        if self.json_files:
            self.create_final_json()
            print(f"\nProcessing complete! Generated {len(self.json_files)} individual analysis files.")
        else:
            print("\nNo files were successfully processed.")

def main():
    if len(sys.argv) != 3:
        print("Usage: python swift_analyzer.py <source_directory> <output_directory>")
        print("Example: python swift_analyzer.py ./src ./output")
        sys.exit(1)
    
    source_dir = sys.argv[1]
    output_dir = sys.argv[2]
    
    if not os.path.exists(source_dir):
        print(f"Error: Source directory '{source_dir}' does not exist!")
        sys.exit(1)
    
    # Check if required tools are available
    required_tools = ['swiftc', 'gdb']
    missing_tools = []
    
    for tool in required_tools:
        if shutil.which(tool) is None:
            missing_tools.append(tool)
    
    if missing_tools:
        print(f"Error: Missing required tools: {', '.join(missing_tools)}")
        print("Please install Swift compiler (swiftc) and GDB")
        sys.exit(1)
    
    analyzer = SwiftAnalyzer(source_dir, output_dir)
    analyzer.run()

if __name__ == "__main__":
    main()