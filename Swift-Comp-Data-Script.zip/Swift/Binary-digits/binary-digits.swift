for num in [5, 50, 9000] {
    println(String(num, radix: 2))
}
