fatalError("You've met with a terrible fate, haven't you?")
