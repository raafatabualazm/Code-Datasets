func jortSort<T:Comparable>(array: [T]) -> Bool {
    return array == sorted(array)
}
