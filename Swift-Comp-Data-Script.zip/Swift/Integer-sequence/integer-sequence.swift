var i = 0
while true {
    println(i++)
}
