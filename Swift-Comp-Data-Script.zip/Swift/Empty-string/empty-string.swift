var s = ""
if s.isEmpty { // alternately, s == ""
  println("s is empty")
} else {
  println("s is not empty")
}
