println(String(26, radix: 16)) // prints "1a"
