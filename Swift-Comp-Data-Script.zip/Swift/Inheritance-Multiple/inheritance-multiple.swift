protocol Camera {

}

protocol Phone {

}

class CameraPhone: Camera, Phone {

}
