func swap<T>(inout a: T, inout b: T) {
  (a, b) = (b, a)
}
