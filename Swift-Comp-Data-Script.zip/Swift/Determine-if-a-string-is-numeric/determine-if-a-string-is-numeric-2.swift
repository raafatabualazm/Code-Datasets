func isNumeric(a: String) -> Bool {
  return a.toInt() != nil
}
