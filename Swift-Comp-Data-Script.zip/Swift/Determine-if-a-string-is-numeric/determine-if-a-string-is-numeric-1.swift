func isNumeric(a: String) -> Bool {
  return Double(a) != nil
}
