import Cocoa

let alert = NSAlert()
alert.messageText = "Goodbye, World!"
alert.runModal()
