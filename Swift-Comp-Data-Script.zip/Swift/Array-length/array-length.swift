let fruits = ["apple", "orange"] // Declare constant array literal
let fruitsCount = fruits.count // Declare constant array length (count)

print(fruitsCount) // Print array length to output window
