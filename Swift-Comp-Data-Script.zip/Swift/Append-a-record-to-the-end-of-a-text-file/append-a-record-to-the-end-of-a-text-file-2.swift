appendPasswd(
	account: "jsmith",
	passwd:"x",
	uid: 1001,
	gid: 1000,
	bio: "Joe Smith,Room 1007,(234)555-8917,(234)555-0077,jsmith@rosettacode.org",
	home: "/home/jsmith",
	shell: "/bin/bash"
)
