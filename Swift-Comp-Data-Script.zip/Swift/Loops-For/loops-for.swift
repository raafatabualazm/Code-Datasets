for i in 1...5 {
    for _ in 1...i {
        print("*", terminator: "")
    }
    print()
}
