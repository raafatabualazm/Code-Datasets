[1,2,3].forEach {
   print($0)
}
