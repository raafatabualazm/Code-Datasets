let x = maxElement([4,3,5,9,2,3])
println(x) // prints 9
