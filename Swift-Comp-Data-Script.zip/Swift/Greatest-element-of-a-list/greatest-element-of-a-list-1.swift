if let x = [4,3,5,9,2,3].maxElement() {
  print(x) // prints 9
}
