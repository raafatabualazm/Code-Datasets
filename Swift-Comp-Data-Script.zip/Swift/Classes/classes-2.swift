MyClass()
