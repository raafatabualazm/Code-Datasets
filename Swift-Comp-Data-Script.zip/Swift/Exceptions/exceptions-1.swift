enum MyException : ErrorType {
  case TerribleException
}
