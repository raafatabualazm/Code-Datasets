func foo() throws {
  throw MyException.TerribleException
}
