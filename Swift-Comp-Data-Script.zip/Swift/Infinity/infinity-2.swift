func getInf() -> Double {
   return Double.infinity
}
