let inf = Double.infinity
inf.isInfinite //true
