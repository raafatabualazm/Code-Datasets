func greet(_ person: String, _ hometown: String) -> String {
    return "Hello \(person)!  Glad you could visit from \(hometown)."
}
print(greet("Bill", "Cupertino"))
