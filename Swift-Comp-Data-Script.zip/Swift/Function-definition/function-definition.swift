func multiply(a: Double, b: Double) -> Double {
   return a * b
}
