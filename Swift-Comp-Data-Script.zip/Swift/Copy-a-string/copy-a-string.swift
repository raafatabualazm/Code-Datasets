var src = "Hello"
var dst = src
