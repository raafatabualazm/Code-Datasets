struct FoodBox<T: Eatable> {
    var food: [T]
}
