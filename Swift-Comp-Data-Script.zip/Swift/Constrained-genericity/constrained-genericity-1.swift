protocol Eatable {
    func eat()
}
