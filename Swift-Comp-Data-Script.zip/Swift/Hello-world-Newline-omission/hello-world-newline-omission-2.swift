print("Goodbye, World!")
