print("Goodbye, World!", terminator: "")
