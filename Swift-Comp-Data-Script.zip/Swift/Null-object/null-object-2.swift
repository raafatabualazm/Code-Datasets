if maybeInt == nil {
  print("variable is nil")
} else {
  print("variable has some value")
}
