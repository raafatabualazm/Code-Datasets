if let certainlyInt = maybeInt {
  print("variable has value \(certainlyInt)")
} else {
  print("variable is nil")
}
