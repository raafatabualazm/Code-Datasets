/**
 Adds two numbers
 :param: a an integer.
 :param: b another integer.
 :returns: the sum of a and b
 */
func add(a: Int, b: Int) -> Int {
    return a + b
}
