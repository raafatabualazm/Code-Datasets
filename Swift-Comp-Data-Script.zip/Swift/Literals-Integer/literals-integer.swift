let hex = 0x2F // Hexadecimal
let bin = 0b101111 // Binary
let oct = 0o57 // Octal
