while true {
    println("SPAM")
}
