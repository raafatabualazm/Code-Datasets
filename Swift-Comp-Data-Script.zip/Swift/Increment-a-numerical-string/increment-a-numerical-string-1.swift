let s = "1234"
if let x = Int(s) {
  print("\(x + 1)")
}
