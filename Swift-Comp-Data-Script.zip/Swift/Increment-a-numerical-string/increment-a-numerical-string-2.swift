let s = "1234"
if let x = s.toInt() {
  println("\(x + 1)")
}
