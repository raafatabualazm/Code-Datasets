for i in stride(from: 1, to: 10, by: 2) {
  print(i)
}
