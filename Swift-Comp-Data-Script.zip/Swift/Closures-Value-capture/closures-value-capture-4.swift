let funcs = [] + map(0..<10) {i in { i * i }}
println(funcs[3]()) // prints 9
