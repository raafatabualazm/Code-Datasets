var letters = [Character]()

for i in 97...122 {
    let char = Character(UnicodeScalar(i))
    letters.append(char)
}
