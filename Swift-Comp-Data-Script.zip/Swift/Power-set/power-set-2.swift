//Example:
powersetFrom(["a", "b", "d"])
