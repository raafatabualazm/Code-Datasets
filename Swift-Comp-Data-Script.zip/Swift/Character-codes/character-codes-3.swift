let i1: UInt32 = 97
println(UnicodeScalar(i1)) // prints "a"
let i2: UInt32 = 960
println(UnicodeScalar(i2)) // prints "π"
