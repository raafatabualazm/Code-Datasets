// Class
MyClass.method(someParameter)
// or equivalently:
let foo = MyClass.self
foo.method(someParameter)

// Instance
myInstance.method(someParameter)

// Method with multiple arguments
myInstance.method(red:arg1, green:arg2, blue:arg3)
