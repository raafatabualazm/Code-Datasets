var i = 1024
while i > 0 {
  println(i)
  i /= 2
}
