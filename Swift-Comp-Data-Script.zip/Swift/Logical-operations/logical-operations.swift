func logic(a: Bool, b: Bool) {
  println("a AND b: \(a && b)");
  println("a OR b: \(a || b)");
  println("NOT a: \(!a)");
}
