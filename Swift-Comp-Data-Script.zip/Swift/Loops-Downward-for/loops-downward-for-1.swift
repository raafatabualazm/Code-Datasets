for i in stride(from: 10, through: 0, by: -1) {
  println(i)
}
