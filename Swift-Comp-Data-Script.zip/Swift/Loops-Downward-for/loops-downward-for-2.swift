for i in lazy(0...10).reverse() {
  println(i)
}
