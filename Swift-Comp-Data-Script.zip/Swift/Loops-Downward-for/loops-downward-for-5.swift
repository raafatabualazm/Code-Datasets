for i in (0...10).reversed() {
    print(i)
}
