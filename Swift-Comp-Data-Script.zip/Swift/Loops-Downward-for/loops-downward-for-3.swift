for i in reverse(0 ... 10) {
  println(i)
}
