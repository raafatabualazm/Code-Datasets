enum SortOrder { case kOrdNone, kOrdLex, kOrdByAddress, kOrdNumeric }

func sortTable(table: [[String]], less: (String,String)->Bool = (<), column: Int = 0, reversed: Bool = false) {
  // . . . Actual sort goes here . . .
}
