isBal("[[[]]]") // true

isBal("[]][[]") // false
