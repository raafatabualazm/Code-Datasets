randBrack(2) // "]][["
