//    ][ is unbalanced
//
//    ]][[ is unbalanced
//
//    []][[] is unbalanced
//
//    [][][[]] is balanced
