print(isatty(STDOUT_FILENO) != 0 ? "TTY" : "Not TTY" )
