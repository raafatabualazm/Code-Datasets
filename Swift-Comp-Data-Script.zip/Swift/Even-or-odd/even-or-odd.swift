// Swift has Int.isMultiple(of:Int) -> Bool

var isEven: (_:Int) -> Bool = {$0.isMultiple(of: 2)}
