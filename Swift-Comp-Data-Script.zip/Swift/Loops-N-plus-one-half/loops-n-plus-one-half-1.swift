for var i = 1; ; i++ {
    print(i)
    if i == 10 {
        println()
        break
    }
    print(", ")
}
