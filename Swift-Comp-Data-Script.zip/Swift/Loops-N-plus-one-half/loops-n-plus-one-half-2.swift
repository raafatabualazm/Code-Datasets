for i in 1...10 {

    print(i, terminator: i == 10 ? "\n" : ", ")
}
