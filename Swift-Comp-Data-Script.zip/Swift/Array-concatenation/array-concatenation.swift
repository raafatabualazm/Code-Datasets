let array1 = [1,2,3]
let array2 = [4,5,6]
let array3 = array1 + array2
