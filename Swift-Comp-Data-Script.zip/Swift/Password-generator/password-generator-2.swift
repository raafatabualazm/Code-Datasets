int getRand(const int upperBound);
void initRandom(const unsigned int seed);
