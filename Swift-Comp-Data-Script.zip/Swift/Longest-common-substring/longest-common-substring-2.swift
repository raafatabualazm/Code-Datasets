lComSubStr("thisisatest", "testing123testing") // "test"
