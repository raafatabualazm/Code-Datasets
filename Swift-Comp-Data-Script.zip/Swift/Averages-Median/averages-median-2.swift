var c: [Double] = (0...100).map {_ in Double.random(in: 0...100)}
print(c.median())
