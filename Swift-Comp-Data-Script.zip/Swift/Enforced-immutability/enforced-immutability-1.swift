let a = 1
a = 1 // error: a is immutable
var b = 1
b = 1
