class Animal {
  // ...
}

class Dog : Animal {
  // ...
}

class Lab : Dog {
  // ...
}

class Collie : Dog {
  // ...
}

class Cat : Animal {
  // ...
}
