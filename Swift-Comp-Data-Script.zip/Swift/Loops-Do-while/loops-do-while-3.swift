var val = 0
do {
   val++
   println(val)
} while val % 6 != 0
