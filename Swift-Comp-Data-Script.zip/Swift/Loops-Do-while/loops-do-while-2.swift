var val = 0
repeat {
  val++
  print(val)
} while val % 6 != 0
