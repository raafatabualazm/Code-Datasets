var val = 0
repeat {
  val += 1
  print(val)
} while val % 6 != 0
