// this is a single line comment
/* This a block comment
   /* containing nested comment */
 */

///This is a documentation comment

/**
  This is a documentation block comment
*/
