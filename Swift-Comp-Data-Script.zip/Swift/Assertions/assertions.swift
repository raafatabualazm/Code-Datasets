var a = 5
//...input or change a here
assert(a == 42) // aborts program when a is not 42
assert(a == 42, "Error message") // aborts program
       // when a is not 42 with "Error message" for the message
       // the error message must be a static string
